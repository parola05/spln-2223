# HPLN

Criação de uma **processador de linguagem natural** em Python.

<br>


![enter image description here](https://raw.githubusercontent.com/henriqueparola/spln-2223/main/TPC4/images/banner.png)

```
usage: hpln.py [-h] [--fl] [--pl] [--pag PAG] texto

Processador de linguagem natural

positional arguments:
  texto       Arquivo de texto de entrada

options:
  -h, --help  show this help message and exit
  --fl        Retorna uma frase por linha
  --pl        Retorna uma palavra por linha
  --pag PAG   Retorna o conteúdo da página fornecida
```


