"Natural Language Processor"
__version__ = "0.7"