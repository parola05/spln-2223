# Shield 

## Description 

Shield is a Data anonymizer tool.




## Authors

* Henrique Parola
* José Pedro
* Alex