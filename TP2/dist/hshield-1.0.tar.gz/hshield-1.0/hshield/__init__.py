"Shield: Data Anonymizer tool"
__version__ = "1.0"